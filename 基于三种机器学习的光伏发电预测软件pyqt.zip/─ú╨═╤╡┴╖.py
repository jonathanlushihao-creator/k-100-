import pandas as pd
import numpy as np

# ========== 1. 强制使用 simhei.ttf 字体 ==========
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

font_path = 'SimHei.ttf'  # 修改为你本机 simhei.ttf 的实际路径
my_font = fm.FontProperties(fname=font_path)
matplotlib.rcParams['font.family'] = my_font.get_name()
# 避免负号 '-' 显示成方块的问题
matplotlib.rcParams['axes.unicode_minus'] = False


from sklearn.model_selection import train_test_split, GridSearchCV, TimeSeriesSplit
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score
import joblib

# --------------- 1. 读取与预处理数据 -----------------
df = pd.read_excel('光伏发电数据整理后.xlsx')
df.fillna(0, inplace=True)
df['日期'] = pd.to_datetime(df['日期'], errors='coerce')
df.dropna(subset=['日期'], inplace=True)

# --------------- 2. 特征选择 -----------------
feature_cols = [
    '集电线发电量（kWh）',
    '上网电量（kWh）',
    '站用变电量（kWh）',
    '辐照量(MJ/㎡)',
    '晴', '少云', '多云', '阴', '雨', '雪'
]

df_model = df.dropna(subset=feature_cols + ['逆变器发电量（kWh）'])
X = df_model[feature_cols]
y = df_model['逆变器发电量（kWh）']

X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                    test_size=0.2,
                                                    random_state=42)

# --------------- 3. 数据标准化 -----------------
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# --------------- 4. 模型训练 -----------------

# 4.1 线性回归
lr_model = LinearRegression()
lr_model.fit(X_train_scaled, y_train)

# 4.2 支持向量机回归（使用 GridSearchCV 调参）
svr = SVR(kernel='rbf')
param_grid_svr = {
    'C': [1, 10, 50, 100, 500],
    'epsilon': [0.1, 1, 5, 10],
    'gamma': ['scale', 'auto']
}

grid_search_svr = GridSearchCV(
    svr,
    param_grid=param_grid_svr,
    cv=5,  # 或用 TimeSeriesSplit(n_splits=5) 针对时序数据
    scoring='r2',
    n_jobs=-1
)
grid_search_svr.fit(X_train_scaled, y_train)
print("SVR 最优参数:", grid_search_svr.best_params_)
svr_best = grid_search_svr.best_estimator_

# 4.3 随机森林（也可调参）
rf_model = RandomForestRegressor(random_state=42)
param_grid_rf = {
    'n_estimators': [50, 100, 200],
    'max_depth': [None, 5, 10, 20],
    'min_samples_split': [2, 5, 10]
}
grid_search_rf = GridSearchCV(
    rf_model,
    param_grid=param_grid_rf,
    cv=5,
    scoring='r2',
    n_jobs=-1
)
grid_search_rf.fit(X_train_scaled, y_train)
print("随机森林最优参数:", grid_search_rf.best_params_)
rf_best = grid_search_rf.best_estimator_

# --------------- 5. 模型评估函数 -----------------
def evaluate_model(model, X_test, y_test, model_name="Model"):
    predictions = model.predict(X_test)
    mse = mean_squared_error(y_test, predictions)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, predictions)
    print(f"{model_name} -- MSE: {mse:.2f}, RMSE: {rmse:.2f}, R2: {r2:.4f}")
    return predictions

print("\n评估结果：")
lr_preds = evaluate_model(lr_model, X_test_scaled, y_test, "线性回归")
svr_preds = evaluate_model(svr_best, X_test_scaled, y_test, "支持向量机")
rf_preds = evaluate_model(rf_best, X_test_scaled, y_test, "随机森林")

# --------------- 6. 可视化预测结果（使用 simhei 字体） -----------------
plt.figure(figsize=(8, 4))
plt.plot(range(len(y_test)), y_test.values, label="真实值")
plt.plot(range(len(y_test)), rf_preds, label="随机森林预测值")
plt.title("随机森林预测 vs 真实值 对比")
plt.xlabel("测试样本索引")
plt.ylabel("逆变器发电量（kWh）")
plt.legend()
plt.show()

plt.figure(figsize=(8, 4))
plt.plot(range(len(y_test)), y_test.values, label="真实值")
plt.plot(range(len(y_test)), lr_preds, label="线性回归预测值")
plt.title("线性回归预测 vs 真实值 对比")
plt.xlabel("测试样本索引")
plt.ylabel("逆变器发电量（kWh）")
plt.legend()
plt.show()

plt.figure(figsize=(8, 4))
plt.plot(range(len(y_test)), y_test.values, label="真实值")
plt.plot(range(len(y_test)), svr_preds, label="SVR预测值")
plt.title("支持向量机预测 vs 真实值 对比")
plt.xlabel("测试样本索引")
plt.ylabel("逆变器发电量（kWh）")
plt.legend()
plt.show()

# --------------- 7. 保存模型 -----------------
joblib.dump(scaler, "scaler.joblib")
joblib.dump(lr_model, "linear_regression_model.joblib")
joblib.dump(svr_best, "svr_model.joblib")
joblib.dump(rf_best, "random_forest_model.joblib")
