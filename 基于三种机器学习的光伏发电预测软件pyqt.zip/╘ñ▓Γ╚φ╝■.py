import sys
import os

import pandas as pd
import numpy as np

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QLabel, QVBoxLayout, QHBoxLayout,
    QPushButton, QRadioButton, QGroupBox, QFileDialog,
    QMessageBox, QDialog, QLineEdit
)

# ================== 1. Matplotlib + simhei 字体设置 ==================
import matplotlib
import matplotlib.font_manager as fm
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

font_path = "SimHei.ttf"
if not os.path.exists(font_path):
    print(f"警告：未找到字体文件 {font_path}，请修改路径或确保文件存在。")
else:
    my_font = fm.FontProperties(fname=font_path)
    matplotlib.rcParams['font.family'] = my_font.get_name()
    matplotlib.rcParams['axes.unicode_minus'] = False

# ================== 2. 机器学习相关库 ==================
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score


class MplCanvas(FigureCanvas):
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)
        super(MplCanvas, self).__init__(fig)
        self.setParent(parent)


class LoginDialog(QDialog):
    """登录对话框"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("用户登录")
        self.setFixedSize(300, 150)

        layout = QVBoxLayout()

        self.username = QLineEdit()
        self.username.setPlaceholderText("用户名")
        self.password = QLineEdit()
        self.password.setPlaceholderText("密码")
        self.password.setEchoMode(QLineEdit.Password)

        self.login_btn = QPushButton("登录")
        self.login_btn.clicked.connect(self.check_credentials)

        layout.addWidget(self.username)
        layout.addWidget(self.password)
        layout.addWidget(self.login_btn)

        self.setLayout(layout)

    def check_credentials(self):
        """简单验证示例，实际应用中应加密处理"""
        if self.username.text() == "admin" and self.password.text() == "123456":
            self.accept()
        else:
            QMessageBox.warning(self, "错误", "用户名或密码错误！")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("光伏电站发电量预测系统")
        self.resize(1200, 700)
        self.setup_ui()

    def setup_ui(self):
        # ============== 主窗口样式设置 ==============
        self.setStyleSheet("""
            QWidget {
                font-size: 14px;
            }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                padding: 8px;
                border-radius: 4px;
                min-width: 100px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QGroupBox {
                border: 1px solid #ddd;
                border-radius: 5px;
                margin-top: 10px;
                padding-top: 15px;
            }
            QLabel {
                margin: 5px;
            }
        """)

        # ============== 主体布局 ==============
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QHBoxLayout()
        main_widget.setLayout(main_layout)

        # ============== 左侧控制面板 ==============
        left_panel = QWidget()
        left_panel.setFixedWidth(350)
        left_layout = QVBoxLayout(left_panel)

        # 文件选择
        self.btn_select_file = QPushButton("选择Excel文件...")
        self.btn_select_file.clicked.connect(self.on_select_file)
        left_layout.addWidget(self.btn_select_file)

        # 文件路径显示
        self.lbl_file_path = QLabel("未选择文件")
        self.lbl_file_path.setWordWrap(True)
        left_layout.addWidget(self.lbl_file_path)

        # 模型选择
        model_group = QGroupBox("选择预测模型")
        model_layout = QVBoxLayout()
        self.radio_lr = QRadioButton("线性回归")
        self.radio_svr = QRadioButton("支持向量机")
        self.radio_rf = QRadioButton("随机森林")
        self.radio_lr.setChecked(True)
        model_layout.addWidget(self.radio_lr)
        model_layout.addWidget(self.radio_svr)
        model_layout.addWidget(self.radio_rf)
        model_group.setLayout(model_layout)
        left_layout.addWidget(model_group)

        # 预测按钮
        self.btn_predict = QPushButton("立即训练并预测")
        self.btn_predict.clicked.connect(self.do_predict)
        left_layout.addWidget(self.btn_predict)

        left_layout.addStretch()
        main_layout.addWidget(left_panel)

        # ============== 右侧结果展示 ==============
        right_panel = QWidget()
        right_layout = QHBoxLayout(right_panel)

        # 结果指标
        result_metrics = QWidget()
        metrics_layout = QVBoxLayout(result_metrics)
        self.label_result_title = QLabel("评估结果：")
        self.label_result_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #333;")
        self.label_result_metrics = QLabel("请先选择文件并点击预测")
        self.label_result_metrics.setStyleSheet("""
            QLabel {
                font-size: 14px;
                color: #666;
                padding: 10px;
                border: 1px solid #eee;
                border-radius: 5px;
                background-color: #f9f9f9;
            }
        """)
        metrics_layout.addWidget(self.label_result_title)
        metrics_layout.addWidget(self.label_result_metrics)
        metrics_layout.addStretch()

        # 图表区域
        self.canvas = MplCanvas(self, width=7, height=5, dpi=100)

        right_layout.addWidget(result_metrics, stretch=1)
        right_layout.addWidget(self.canvas, stretch=2)
        main_layout.addWidget(right_panel, stretch=1)

        # 数据缓存
        self.df = None

    def on_select_file(self):
        # 保持原有文件选择逻辑不变
        file_dialog = QFileDialog()
        file_dialog.setNameFilter("Excel Files (*.xls *.xlsx)")
        if file_dialog.exec_():
            selected_files = file_dialog.selectedFiles()
            if selected_files:
                file_path = selected_files[0]
                self.lbl_file_path.setText(file_path)
                try:
                    self.df = pd.read_excel(file_path)
                    QMessageBox.information(self, "提示", "Excel文件加载成功！")
                except Exception as e:
                    QMessageBox.critical(self, "错误", f"读取Excel失败：{e}")
                    self.df = None

    def do_predict(self):
        # 保持原有预测逻辑不变
        if self.df is None:
            QMessageBox.warning(self, "警告", "请先选择Excel文件！")
            return

        self.canvas.axes.clear()

        df = self.df.copy()
        df.fillna(0, inplace=True)

        required_cols = [
            '日期', '逆变器发电量（kWh）', '集电线发电量（kWh）',
            '上网电量（kWh）', '站用变电量（kWh）', '辐照量(MJ/㎡)',
            '晴', '少云', '多云', '阴', '雨', '雪'
        ]

        for c in required_cols:
            if c not in df.columns:
                QMessageBox.critical(self, "错误", f"缺少必要列：{c}")
                return

        df['日期'] = pd.to_datetime(df['日期'], errors='coerce')

        target_col = '逆变器发电量（kWh）'
        feature_cols = [
            '集电线发电量（kWh）', '上网电量（kWh）', '站用变电量（kWh）',
            '辐照量(MJ/㎡)', '晴', '少云', '多云', '阴', '雨', '雪'
        ]

        df = df.dropna(subset=feature_cols + [target_col])

        if len(df) < 2:
            QMessageBox.warning(self, "警告", "有效数据量不足，无法训练模型！")
            return

        X = df[feature_cols].values
        y = df[target_col].values

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, random_state=42
        )

        if self.radio_lr.isChecked():
            model_name = "线性回归"
            model = LinearRegression()
        elif self.radio_svr.isChecked():
            model_name = "支持向量机"
            model = SVR(kernel='rbf', C=100)
        else:
            model_name = "随机森林"
            model = RandomForestRegressor(n_estimators=100, random_state=42)

        try:
            model.fit(X_train, y_train)
        except Exception as e:
            QMessageBox.critical(self, "错误", f"模型训练失败：{e}")
            return

        y_pred = model.predict(X_test)
        mse_val = mean_squared_error(y_test, y_pred)
        rmse_val = np.sqrt(mse_val)
        r2_val = r2_score(y_test, y_pred)

        info_str = (
            f"模型：{model_name}\n"
            f"测试集样本量：{len(y_test)}\n\n"
            f"MSE：{mse_val:.2f}\n"
            f"RMSE：{rmse_val:.2f}\n"
            f"R²：{r2_val:.4f}\n"
        )
        self.label_result_metrics.setText(info_str)

        # 绘制图表
        x_range = range(len(y_test))
        self.canvas.axes.plot(x_range, y_test, label="真实值", marker='o', markersize=4)
        self.canvas.axes.plot(x_range, y_pred, label="预测值", marker='x', markersize=4)
        self.canvas.axes.set_title("真实值 vs. 预测值")
        self.canvas.axes.set_xlabel("测试样本索引")
        self.canvas.axes.set_ylabel("逆变器发电量（kWh）")
        self.canvas.axes.legend()
        self.canvas.axes.grid(True, linestyle='--', alpha=0.6)
        self.canvas.draw()


def main():
    app = QtWidgets.QApplication(sys.argv)

    # 显示登录界面
    login_dialog = LoginDialog()
    if login_dialog.exec_() != QDialog.Accepted:
        sys.exit(0)

    # 登录成功后显示主界面
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()