import logging

import flask
from flask import Flask
from flask_cors import CORS, cross_origin

from net_analyse.network import NetAnalyse

app = Flask(__name__)
net = NetAnalyse()


@app.route('/api/net/search', methods=['POST'])
@cross_origin(methods=['POST'])
def _search_net_info():
    data = flask.request.get_json()
    protocol = data.get('protocol')
    size = data.get('size')
    try:
        result = net.get_net_info(protocol, size)
        _result = {
            "success": True,
            "data": result
        }
        return _result
    except Exception as e:
        raise e


@app.route('/api/net/analyse', methods=['POST'])
@cross_origin(methods=['POST'])
def analyse_data():
    data = flask.request.get_json()
    req_type = data.get('req_type')
    try:
        result = net.get_data(req_type)
        _result = {
            "success": True,
            "data": result
        }
        return _result
    except Exception as e:
        raise e


@app.route('/api/net/alert', methods=['POST'])
@cross_origin(methods=['POST'])
def get_alert_data():
    try:
        result = net.get_alert_data()
        _result = {
            "success": True,
            "data": result
        }
        return _result
    except Exception as e:
        raise e


@app.route('/api/net/execute', methods=['POST'])
@cross_origin(methods=['POST'])
def execute_action():
    data = flask.request.get_json()
    act_type = data.get('act_type')
    protocol = data.get('protocol')
    net_card = data.get('net_card')
    try:
        result = net.execute_act(act_type, protocol, net_card)
        _result = {
            "success": True,
            "data": result
        }
        return _result
    except Exception as e:
        raise e


if __name__ == '__main__':
    _host = '0.0.0.0'
    _port = 5000
    logging.info(f"服务启动，启动host:{_host}, 监听端口：{_port}")
    app.run(host=_host, port=_port)
