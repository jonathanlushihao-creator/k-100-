import datetime
import threading

import pyshark

from mysql_connect import MysqlConnect

thread = None


class NetCollection(object):
    def __init__(self):
        self.db = MysqlConnect()

    def collect_by_wireshark(self, protocol, net_card):
        try:
            net_card = 'en0'
            if net_card is not None and net_card != '':
                capture = pyshark.LiveCapture(interface='en0')
            else:
                capture = pyshark.LiveCapture(interface='en0')
            # 获取所有的捕获数据包
            for packet in capture.sniff_continuously():
                src_ip = ''
                dst_ip = ''
                if packet is not None and packet.ip is not None:
                    # 获取数据包的源IP地址
                    src_ip = packet.ip.src
                    # 获取数据包的目的IP地址
                    dst_ip = packet.ip.dst
                # 获取数据包的协议
                protocol = packet.transport_layer
                # 输出数据包的信息
                net_time = datetime.datetime.now()
                length = 100
                info = 'from:' + src_ip + ' ; to: ' + dst_ip
                rec_time = datetime.datetime.now()
                if src_ip is not None and dst_ip is not None:
                    sql = (
                        f"insert into net_parse_info(net_time,net_card,req_src,req_dst,protocol,length,info,rec_time) "
                        f"values ('{net_time}','{net_card}','{src_ip}','{dst_ip}','{protocol}','{length}','{info}','{rec_time}')")
                    print(sql)
                    exec_result = self.db.execute(sql)
        except Exception as e:
            print(e)

    def collect_by_tcpdump(self, sql):
        self.db.execute(sql)

    def start_collect(self, protocol, net_card):
        print(protocol)
        print(net_card)
        # thread = threading.Thread(target=self.collect_by_wireshark, args=(protocol, net_card,), name='TestThread')
        # thread.start()
        self.collect_by_wireshark(protocol, net_card)
        return "开始抓取网络包信息"

    def alert_info(self, alert_num):
        sql = "select  req_src as name ,date_format(net_time,'%Y-%m-%d %H:%i:%S') as datetime, count(1) as num from net_parse_info group by  name,datetime"
        result = self.db.execute(sql)
        if result is not None and len(result) > 0:
            num = result[0]['num']
            alert_time = datetime.datetime.now()
            alert_code = 'alert-001'
            alert_name = '相同IP同一时间，请求超过10次'
            req_ip = 'alert-001'
            req_port = 'alert-001'
            alert_num = 0
            alert_reason = 'alert-001'
            rec_time = datetime.datetime.now()
            if num > alert_num:
                sqls = (
                    f'insert into net_alert_info(alert_time,alert_code, alert_name, req_ip,req_port,alert_num,alert_reason, rec_time) '
                    f'values ("{alert_time}","{alert_code}","{alert_name}","{req_ip}","{req_port}","{alert_num}","{alert_reason}","{rec_time}")')
                self.db.execute(sqls)

    def stop_process(self):
        if thread is not None:
            thread.join()


if __name__ == '__main__':
    net = NetCollection()
    net.alert_info(1)
