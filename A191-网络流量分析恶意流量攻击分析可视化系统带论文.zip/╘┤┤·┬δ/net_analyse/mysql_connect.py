import datetime
import json
import os
import sys

from RPA.Database import Database
from RPA.Tables import Table

if getattr(sys, 'frozen', False):
    datadir = os.path.dirname(sys.executable)
else:
    datadir = os.path.dirname(__file__)

with open(os.path.join(datadir, 'config.json'), 'r', encoding="utf-8") as json_file:
    config = json.load(json_file)


class MysqlConnect(object):
    def __init__(self):
        self.db = Database()
        self.db.connect_to_database(module_name='pymysql',
                                    host=config.get('host'),
                                    port=3306,
                                    database=config.get('database'),
                                    username=config.get('username'),
                                    password=config.get('password')
                                    )

    def execute(self, sql):
        _result = self.db.query(statement=sql)
        if type(_result) == Table:
            data_list = []
            if _result.data and len(_result.data) > 0:
                for line_a in _result.data:
                    data = {}
                    cnt = 0
                    for data_b in line_a:
                        data[_result.columns[cnt]] = data_b
                        cnt += 1
                    data_list.append(data)
            _result = data_list
        return _result
