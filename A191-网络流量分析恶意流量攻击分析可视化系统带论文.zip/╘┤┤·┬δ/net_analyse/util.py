import base64
import json
import requests


def post_http(server_url, url, headers=None, params=None):
    if params is None:
        params = {}
    if headers is None:
        headers = {'Content-type': 'application/json;charset=UTF-8', 'Accept': 'application/json, text/plain'}
    req_url = server_url + url
    response = requests.post(req_url, data=json.dumps(params),
                             headers=headers)
    datas = ''
    if response:
        if response.status_code == 200:
            byte_content = response.content
            content = str(byte_content, 'utf-8')
            data = json.loads(content)
            datas = data.get('data')
            print(datas)
    return datas
