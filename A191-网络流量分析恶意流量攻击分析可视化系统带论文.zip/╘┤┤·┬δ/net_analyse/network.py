import pymysql

from net_analyse.mysql_connect import MysqlConnect
from net_analyse.net_collection import NetCollection


class NetAnalyse(object):
    def __init__(self):
        self.db = MysqlConnect()
        self.collect = NetCollection()
        self.process_map = []

    def get_net_info(self, protocol=None, size=None):
        sql = "select  date_format(net_time, '%Y-%m-%d %H:%i:%S') as net_time, net_card, req_src, req_dst, protocol, length, info, date_format(rec_time, '%Y-%m-%d %H:%i:%S')   as rec_time from net_parse_info where 1 = 1 "
        if protocol is not None:
            sql += f' and protocol = {protocol}'
        if size is not None:
            sql += f'  limit {size}'
        else:
            sql += f'  limit 5'
        result = self.db.execute(sql)
        return result

    def get_data(self, req_type=None):
        sql = "select req_src, req_src as port, count(1) as num from net_parse_info group by req_src, req_src"
        if req_type == 'protocol':
            sql = 'select protocol as name , count(1) as num from net_parse_info group by protocol'
        elif req_type == 'card':
            sql = 'select net_card as name, count(1) as num from net_parse_info group by net_card;'
        elif req_type == 'realtime':
            sql = 'select info from net_parse_info order by net_time   desc limit 1;'

        result = self.db.execute(sql)
        return result

    def get_alert_data(self):
        result = {}
        sql = "select date_format(alert_time,'%Y-%m-%d %H:%i:%S') as alert_time, alert_code, alert_name, req_ip, req_port, alert_num, alert_reason, date_format(rec_time,'%Y-%m-%d %H:%i:%S') as  rec_time  from net_alert_info order by rec_time desc limit 5"
        result1 = self.db.execute(sql)
        result['list'] = result1
        sql = "select  alert_name as name , count(1) as num from net_alert_info group by  name"
        result2 = self.db.execute(sql)
        result['alert_name'] = result2
        sql = "select  req_ip as name , count(1) as num from net_alert_info group by  req_ip"
        req_ip = self.db.execute(sql)
        result['req_ip'] = req_ip
        sql = "select  req_port as name , count(1) as num from net_alert_info group by  req_port"
        req_port = self.db.execute(sql)
        result['req_port'] = req_port
        return result

    def execute_act(self, act_type=None, protocol=None, net_card=None):
        try:
            print(f"act_type is {act_type}")
            if act_type == 'start':
                self.collect.start_collect(protocol, net_card)
                result = "开始抓取网络包信息"
            else:
                # result = self.collect.stop_process()
                result = "结束抓取网络包信息"
            return result
        except Exception as e:
            print(e)
