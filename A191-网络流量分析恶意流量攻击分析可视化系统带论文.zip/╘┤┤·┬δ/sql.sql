create schema parttime collate utf8mb4_bin;



-- auto-generated definition
create table net_parse_info
(
    Id        bigint auto_increment
        primary key,
    net_time  datetime     null comment '抓包时间',
    net_card  varchar(50)  null comment 'net_card',
    req_src   varchar(50)  null comment 'source',
    req_dst   varchar(50)  null comment 'dest',
    protocol  varchar(50)  null comment 'protocol',
    length    varchar(100) null comment 'length',
    info      text         null comment 'info',
    rec_time datetime     null comment '记录时间'
)
    charset = utf8mb3
    row_format = DYNAMIC;



-- auto-generated definition
create table net_alert_info
(
    Id           bigint auto_increment
        primary key,
    alert_time   datetime     null comment 'alert_time',
    alert_code   varchar(50)  null comment 'source',
    alert_name   varchar(100) null comment 'alert_name',
    req_ip       varchar(50)  null comment 'req_ip',
    req_port     varchar(100) null comment 'req_port',
    alert_num    bigint       null comment 'num',
    alert_reason text         null comment 'alert_reason',
    rec_time     datetime     null comment '记录时间'
)
    charset = utf8mb3
    row_format = DYNAMIC;

INSERT INTO parttime.net_alert_info (Id, alert_time, alert_code, alert_name, req_ip, req_port, alert_num, alert_reason, rec_time) VALUES (1, '2024-02-23 22:21:28', 'code001', '的发声法', '100001', '80', 1000, 'nishi ', '2024-02-23 22:21:59');
INSERT INTO parttime.net_alert_info (Id, alert_time, alert_code, alert_name, req_ip, req_port, alert_num, alert_reason, rec_time) VALUES (2, '2024-02-25 13:19:11', 'alert-001', 'alert-001', 'alert-001', 'alert-001', 0, 'alert-001', '2024-02-25 13:19:11');
INSERT INTO parttime.net_alert_info (Id, alert_time, alert_code, alert_name, req_ip, req_port, alert_num, alert_reason, rec_time) VALUES (3, '2024-02-25 21:24:14', 'alert-001', '相同IP同一时间，请求超过10次', 'alert-001', 'alert-001', 0, 'alert-001', '2024-02-25 21:24:14');

