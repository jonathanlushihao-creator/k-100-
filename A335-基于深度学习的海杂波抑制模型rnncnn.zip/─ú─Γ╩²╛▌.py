import numpy as np
import pandas as pd

def generate_and_save_data():
    # 数据参数
    N = 10
    range_bins = 15
    time_steps = 2000

    # 生成模拟数据
    X = np.random.rand(N, 1, range_bins, time_steps).astype(np.float32)
    Y = np.random.rand(N, 1, range_bins, time_steps).astype(np.float32)

    # 重塑数据为二维数组以保存到 CSV
    # X 和 Y 的形状从 (N, 1, range_bins, time_steps) 转换为 (N, range_bins * time_steps)
    X_reshaped = X.reshape(N, -1)
    Y_reshaped = Y.reshape(N, -1)

    # 创建列名
    columns = [f'pixel_{i}' for i in range(range_bins * time_steps)]

    # 转换为 DataFrame
    X_df = pd.DataFrame(X_reshaped, columns=columns)
    Y_df = pd.DataFrame(Y_reshaped, columns=columns)

    # 保存到 CSV 文件
    X_df.to_csv('sea_clutter_X.csv', index=False)
    Y_df.to_csv('sea_clutter_Y.csv', index=False)

    print("模拟数据已保存到 sea_clutter_X.csv 和 sea_clutter_Y.csv")

if __name__ == "__main__":
    generate_and_save_data()