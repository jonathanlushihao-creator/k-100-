import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error

# 加载本地 SimHei 字体
font_path = "SimHei.ttf"  # 请确保此文件存在于代码运行目录下
font_manager.fontManager.addfont(font_path)
plt.rcParams['font.family'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False

# ==========================================
# 一、数据集定义
# ==========================================
class SeaClutterDataset(Dataset):
    def __init__(self, X, Y, range_bins=15, time_steps=2000):
        super(SeaClutterDataset, self).__init__()
        self.X = X
        self.Y = Y
        self.range_bins = range_bins
        self.time_steps = time_steps

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        x_data = self.X[idx].reshape(1, self.range_bins, self.time_steps)
        y_data = self.Y[idx].reshape(1, self.range_bins, self.time_steps)
        return x_data, y_data

# ==========================================
# 二、混合 CNN + RNN 模型
# ==========================================
class CNNRNNNet(nn.Module):
    def __init__(self,
                 in_channels=1,
                 hidden_cnn=16,
                 hidden_rnn=32,
                 range_bins=15,
                 time_steps=2000,
                 rnn_layers=1):
        super(CNNRNNNet, self).__init__()

        self.range_bins = range_bins
        self.time_steps = time_steps
        self.hidden_cnn = hidden_cnn
        self.hidden_rnn = hidden_rnn
        self.rnn_layers = rnn_layers

        # CNN 特征提取
        self.feature_extractor = nn.Sequential(
            nn.Conv2d(in_channels, hidden_cnn, kernel_size=3, padding=1),
            nn.BatchNorm2d(hidden_cnn),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_cnn, hidden_cnn, kernel_size=3, padding=1),
            nn.BatchNorm2d(hidden_cnn),
            nn.ReLU(inplace=True)
        )

        # RNN: LSTM
        self.rnn = nn.LSTM(
            input_size=hidden_cnn * range_bins,
            hidden_size=hidden_rnn,
            num_layers=rnn_layers,
            batch_first=True
        )

        self.fc_rnn_out = nn.Linear(hidden_rnn, hidden_cnn * range_bins)

        # 重建输出
        self.reconstructor = nn.Sequential(
            nn.Conv2d(hidden_cnn, 8, kernel_size=3, padding=1),
            nn.BatchNorm2d(8),
            nn.ReLU(inplace=True),
            nn.Conv2d(8, 1, kernel_size=3, padding=1),
            nn.Sigmoid()
        )

    def forward(self, x):
        feat = self.feature_extractor(x)
        B, C, R, T = feat.shape
        feat_rnn_in = feat.permute(0, 3, 1, 2).reshape(B, T, C * R)
        rnn_out, _ = self.rnn(feat_rnn_in)
        rnn_out_fc = self.fc_rnn_out(rnn_out)
        rnn_out_fc = rnn_out_fc.reshape(B, T, C, R).permute(0, 2, 3, 1)
        out = self.reconstructor(rnn_out_fc)
        return out

# ==========================================
# 三、PSNR 计算函数
# ==========================================
def calculate_psnr(pred, target, max_val=1.0):
    mse = torch.mean((pred - target) ** 2)
    if mse == 0:
        return float('inf')
    psnr = 20 * torch.log10(torch.tensor(max_val)) - 10 * torch.log10(mse)
    return psnr.item()

# ==========================================
# 四、训练脚本
# ==========================================
def train_model():
    # 参数
    range_bins = 15
    time_steps = 2000
    batch_size = 2
    epochs = 20

    # 加载 CSV 数据
    X_df = pd.read_csv('sea_clutter_X.csv')
    Y_df = pd.read_csv('sea_clutter_Y.csv')

    # 转换为 numpy 数组
    X = X_df.values.astype(np.float32)
    Y = Y_df.values.astype(np.float32)

    # 划分训练集和验证集
    X_train, X_val, Y_train, Y_val = train_test_split(X, Y, test_size=0.2, random_state=42)

    # 创建数据集
    train_dataset = SeaClutterDataset(X_train, Y_train, range_bins, time_steps)
    val_dataset = SeaClutterDataset(X_val, Y_val, range_bins, time_steps)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

    # 初始化模型、损失和优化器
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = CNNRNNNet(
        in_channels=1,
        hidden_cnn=16,
        hidden_rnn=32,
        range_bins=range_bins,
        time_steps=time_steps,
        rnn_layers=1
    ).to(device)

    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=1e-3)

    # 记录训练和验证指标
    train_losses = []
    val_losses = []
    train_maes = []
    val_maes = []
    train_psnrs = []
    val_psnrs = []

    # 训练循环
    for epoch in range(epochs):
        # 训练
        model.train()
        running_loss = 0.0
        running_mae = 0.0
        running_psnr = 0.0
        for x_data, y_data in train_loader:
            x_data = x_data.to(device)
            y_data = y_data.to(device)

            optimizer.zero_grad()
            outputs = model(x_data)
            loss = criterion(outputs, y_data)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            mae = mean_absolute_error(outputs.cpu().detach().numpy().flatten(),
                                     y_data.cpu().detach().numpy().flatten())
            running_mae += mae
            psnr = calculate_psnr(outputs, y_data)
            running_psnr += psnr

        avg_train_loss = running_loss / len(train_loader)
        avg_train_mae = running_mae / len(train_loader)
        avg_train_psnr = running_psnr / len(train_loader)
        train_losses.append(avg_train_loss)
        train_maes.append(avg_train_mae)
        train_psnrs.append(avg_train_psnr)

        # 验证
        model.eval()
        val_loss = 0.0
        val_mae = 0.0
        val_psnr = 0.0
        with torch.no_grad():
            for x_data, y_data in val_loader:
                x_data = x_data.to(device)
                y_data = y_data.to(device)
                outputs = model(x_data)
                loss = criterion(outputs, y_data)
                val_loss += loss.item()
                mae = mean_absolute_error(outputs.cpu().detach().numpy().flatten(),
                                         y_data.cpu().detach().numpy().flatten())
                val_mae += mae
                psnr = calculate_psnr(outputs, y_data)
                val_psnr += psnr

        avg_val_loss = val_loss / len(val_loader)
        avg_val_mae = val_mae / len(val_loader)
        avg_val_psnr = val_psnr / len(val_loader)
        val_losses.append(avg_val_loss)
        val_maes.append(avg_val_mae)
        val_psnrs.append(avg_val_psnr)

        print(f"Epoch [{epoch + 1}/{epochs}]")
        print(f"Train Loss: {avg_train_loss:.6f}, MAE: {avg_train_mae:.6f}, PSNR: {avg_train_psnr:.2f}")
        print(f"Val Loss: {avg_val_loss:.6f}, MAE: {avg_val_mae:.6f}, PSNR: {avg_val_psnr:.2f}")

    print("训练结束。")

    # 可视化训练曲线
    plt.figure(figsize=(15, 5))

    # 损失曲线
    plt.subplot(1, 3, 1)
    plt.plot(train_losses, label='训练损失')
    plt.plot(val_losses, label='验证损失')
    plt.xlabel('轮次')
    plt.ylabel('损失')
    plt.title('训练和验证损失')
    plt.legend()

    # MAE 曲线
    plt.subplot(1, 3, 2)
    plt.plot(train_maes, label='训练 MAE')
    plt.plot(val_maes, label='验证 MAE')
    plt.xlabel('轮次')
    plt.ylabel('MAE')
    plt.title('训练和验证 MAE')
    plt.legend()

    # PSNR 曲线
    plt.subplot(1, 3, 3)
    plt.plot(train_psnrs, label='训练 PSNR')
    plt.plot(val_psnrs, label='验证 PSNR')
    plt.xlabel('轮次')
    plt.ylabel('PSNR')
    plt.title('训练和验证 PSNR')
    plt.legend()

    plt.tight_layout()
    plt.show()

    # 测试推理并可视化多个样本
    model.eval()
    num_samples = min(3, len(val_dataset))  # 显示最多 3 个样本
    with torch.no_grad():
        for i in range(num_samples):
            sample_x, sample_y = val_dataset[i]
            # 转换为张量并添加批次维度
            sample_x = torch.tensor(sample_x, dtype=torch.float32).unsqueeze(0).to(device)
            sample_y = torch.tensor(sample_y, dtype=torch.float32).to(device)
            pred = model(sample_x)

            # 转换为 numpy 用于可视化
            pred_np = pred.squeeze().cpu().numpy()  # 移除所有大小为 1 的维度，变为 (15, 2000)
            x_np = sample_x.squeeze().cpu().numpy()  # 移除所有大小为 1 的维度，变为 (15, 2000)
            y_np = sample_y.squeeze().cpu().numpy()  # 移除通道维度，变为 (15, 2000)

            # 可视化
            plt.figure(figsize=(15, 8))

            # 输入
            plt.subplot(2, 3, 1)
            plt.imshow(x_np, aspect='auto', cmap='jet')
            plt.title("输入：含海杂波的回波")
            plt.xlabel("时间")
            plt.ylabel("距离单元")

            # 真实输出
            plt.subplot(2, 3, 2)
            plt.imshow(y_np, aspect='auto', cmap='jet')
            plt.title("真实：抑制后")
            plt.xlabel("时间")
            plt.ylabel("距离单元")

            # 预测输出
            plt.subplot(2, 3, 3)
            plt.imshow(pred_np, aspect='auto', cmap='jet')
            plt.title("预测：抑制后")
            plt.xlabel("时间")
            plt.ylabel("距离单元")

            # 残差图
            plt.subplot(2, 3, 4)
            residual = np.abs(pred_np - y_np)
            plt.imshow(residual, aspect='auto', cmap='viridis')
            plt.title("残差图 (|预测 - 真实|)")
            plt.xlabel("时间")
            plt.ylabel("距离单元")
            plt.colorbar(label='残差值')

            # 预测误差分布
            plt.subplot(2, 3, 5)
            errors = (pred_np - y_np).flatten()
            sns.histplot(errors, bins=50, kde=True)
            plt.title("预测误差分布")
            plt.xlabel("误差")
            plt.ylabel("频率")

            plt.tight_layout()
            plt.show()
    # 打印最终评估指标
    print("\n最终评估指标（验证集）：")
    print(f"平均 MSE Loss: {val_losses[-1]:.6f}")
    print(f"平均 MAE: {val_maes[-1]:.6f}")
    print(f"平均 PSNR: {val_psnrs[-1]:.2f}")

if __name__ == "__main__":
    train_model()