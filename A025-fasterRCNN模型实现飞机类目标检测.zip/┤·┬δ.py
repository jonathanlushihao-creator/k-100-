import pandas as pd
from PIL import Image
import cv2
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
import torch
from torch import nn, Tensor
import torchvision
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from torchvision import transforms as T
from torchvision.transforms import functional as F

# 配置信息
data_path = './plane_box.csv'
split_ratio = 0.8 # 训练集 & 验证集切割比例
random_seed = 321  # 随机数种子
pretrained_path = './fasterrcnn_resnet50_fpn_coco-258fb6c6.pth' # 预训练模型地址
flip_rate = 0.5 # 数据增强翻转比例
batch_size = 2  # 批次大小
epochN = 10 # 训练轮次
learning_rate = 0.0005 # 学习率
model_path = 'plane_best.pth'

data = pd.read_csv(data_path)
show_record = data[data['image_id']=='P0037'].reset_index(drop=True)
img_path = show_record['path'][0]
images = np.array(Image.open(img_path))

for i in range(len(show_record)):
    [x0, y0, x1, y1] = [int(float(x)) for x in show_record.loc[i][['xmin', 'ymin', 'xmax', 'ymax']]]
    image = cv2.rectangle(images, (x0, y0), (x1, y1), (0, 255, 255), 4)
plt.imshow(image)

display(data.head())
targets = set(data['label'])
num_classes = len(targets)+1
print(f"数据共有{len(set(data['image_id']))}张图片")
print("每张图片存在多个标注框，每行为一个标注框的信息，包括四个点坐标、长、宽、标签")
print(f"标签值为{targets}，代表目标，模型分类数为{num_classes}（背景：0，目标：{targets}）")

class RandomHorizontalFlip(T.RandomHorizontalFlip):
    def forward(self, image, target=None):
        if torch.rand(1) < self.p:
            image = F.hflip(image)
            if target is not None:
                if "boxes" in target:
                    _, _, width = image.shape
                    target["boxes"][:, [0, 2]] = width - target["boxes"][:, [2, 0]]
                if "masks" in target:
                    target["masks"] = target["masks"].flip(-1)
        return image, target

class PILToTensor(nn.Module):
    def forward(self, image, target=None):
        image = F.pil_to_tensor(image)
        return image, target

class Compose:
    def __init__(self, transforms):
        self.transforms = transforms

    def __call__(self, image, target=None):
        for t in self.transforms:
            image, target = t(image, target)
        return image, target

def get_transform(train):
    get_transforms = []
    get_transforms.append(PILToTensor())
    if train:
        get_transforms.append(RandomHorizontalFlip(flip_rate))
    return Compose(get_transforms)
# 拆分训练集 & 验证集
df = pd.read_csv(data_path)
display(df[800:810])
df = df[:805] # 采用前805行数据作为训练、验证数据，可根据需求与算力调整
print(df.shape)
img_ids = list(set(df['image_id']))
img_train, img_val = train_test_split (img_ids, train_size=split_ratio, random_state=random_seed)
df_train = df[df['image_id'].isin(img_train)]
df_val = df[df['image_id'].isin(img_val)]
print(f"训练集{len(img_train)}张图，{len(df_train)}行，验证集{len(img_val)}张图{len(df_val)}行")


class DetectDataset(torch.utils.data.Dataset):
        def __init__(self, df, transforms, train):
                self.transforms = transforms
                self.df = df
                self.train = train
                self.img_id = df['image_id'].unique()

        def __getitem__(self, idx):
                target_id = self.img_id[idx]
                target_df = self.df[self.df['image_id'] == target_id].reset_index(drop=True)
                img_path = target_df['path'][0]
                img = Image.open(img_path).convert('RGB')

                target = {
                        "boxes": np.array(target_df[['xmin', 'ymin', 'xmax', 'ymax']]),
                        "labels": torch.as_tensor(target_df['label']),
                        "image_id": target_id,
                        "iscrowd": torch.as_tensor([0] * len(target_df)),
                        "area": torch.as_tensor(
                                (target_df['xmax'] - target_df['xmin']) * (target_df['ymax'] - target_df['ymin']))}

                img, target = get_transform(self.train)(img, target)
                img = img / 255
                target["boxes"] = torch.as_tensor(target["boxes"], dtype=torch.float32)
                return img, target

        def __len__(self):
                return len(self.img_id)


train_set = DetectDataset(df_train, get_transform, True)
val_set = DetectDataset(df_val, get_transform, False)
def collate_fn(batch):
    return tuple(zip(*batch))

data_loader_train = torch.utils.data.DataLoader(
    train_set, batch_size=batch_size, shuffle=True,
    num_workers=0, collate_fn=collate_fn
    )

data_loader_val = torch.utils.data.DataLoader(
    val_set, batch_size=batch_size, shuffle=False,
    num_workers=0, collate_fn=collate_fn
    )
print(len(data_loader_train), len(data_loader_val))
def get_model_instance_segmentation(num_classes):
    model = torchvision.models.detection.fasterrcnn_resnet50_fpn(pretrained_backbone=False)
    model.load_state_dict(torch.load(pretrained_path))

    in_features = model.roi_heads.box_predictor.cls_score.in_features # we need to change the head
    model.roi_heads.box_predictor = torchvision.models.detection.faster_rcnn.FastRCNNPredictor(in_features, num_classes)

    return model

model = get_model_instance_segmentation(num_classes)
device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
model.to(device)
r.init_ml() # 训练记录初始化
r.start_ml() # 开始训练记录

# construct an optimizer
optimizer = torch.optim.SGD(model.parameters(), lr=0.005, momentum=0.9, weight_decay=0.0005)
# and a learning rate scheduler
lr_scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=3, gamma=0.1)


for epoch in range(epochN):
    print(f"Epoch:[{epoch}/{epochN}]")
    loss_train, loss_val = [], []
    loss_cla_train, loss_cla_val = [], []
    model.train()
    for idx, batch in enumerate(data_loader_train):
        input_, label_ = batch[0], batch[1]
        input_ = list(image.to(device) for image in input_)
        label_ = [{k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in t.items()} for t in label_]
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        optimizer.zero_grad()
        loss_dict = model(input_, label_)
        losses = sum(loss for loss in loss_dict.values())
        losses.backward()
        optimizer.step()

        loss_train.append(float(losses))
        loss_cla_train.append(float(loss_dict['loss_classifier']))
        if idx%10==0:
            print(f"Train: [{idx}/{len(data_loader_train)}] loss_classifier: {round(float(loss_dict['loss_classifier']), 4)}, loss_box_reg: {round(float(loss_dict['loss_box_reg']), 4)}, loss_objectness: {round(float(loss_dict['loss_objectness']), 4)}, loss_rpn_box_reg: {round(float(loss_dict['loss_rpn_box_reg']), 4)}")
    print(f"Train: loss:{np.mean(loss_train)} loss_classifier: {np.mean(loss_cla_train)}")
    r.log_ml(epoch=epoch, phase="train", loss=np.mean(loss_train), custom_logs = {"loss_classifier": np.mean(loss_cla_train)}) # 记录训练过程的关键信

    lr_scheduler.step()

    with torch.no_grad():
        for (input_, label_) in data_loader_val:
            input_ = list(image.to(device) for image in input_)
            label_ = [{k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in t.items()} for t in label_]
            if torch.cuda.is_available():
                torch.cuda.synchronize()
            loss_dict = model(input_, label_)
            losses = sum(loss for loss in loss_dict.values())
            loss_val.append(float(losses))
            loss_cla_val.append(float(loss_dict['loss_classifier']))
        print(f"Val: loss:{np.mean(loss_val)} loss_classifier: {np.mean(loss_cla_val)}")
from engine import evaluate
evaluate(model, data_loader_val, device=device)
torch.save(model.state_dict(), model_path)